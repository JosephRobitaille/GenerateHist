#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>  // setw
#include <fstream>
#include <functional>
#include <sstream>
#include<stdlib.h>
#include<algorithm>
#include<stdio.h>
#include <string>
#include <vector>
#include<ctype.h>
#include <memory>
#include<set>
#include<map>
#include <chrono>
#include <random>
#include "Alternative.cpp"
using namespace std;


vector<double> createroulette(int nb_days)
{
	vector<double> weights;
	double indweights = 1.0 / double(nb_days);
	double sumweights = 0.0;
	for (int i = 0; i < nb_days-1; i++)
	{
		sumweights += indweights;
		weights.push_back(sumweights);
	}
	weights.push_back(1.0);
	return weights;
}

int draw(vector<double> roulette, vector<int> days_chosen, vector<int> days_tobechoose)
{
	bool check = false;
	int final_int;
	while (check == false)
	{
		bool check2 = false;
		int test_int;
		double rdm = (double)rand() / ((double)RAND_MAX + 1);
		int numb = 0;
		while (check2 == false)
		{
			if (rdm <= roulette.at(numb))
			{
				test_int = numb;
				check2 = true;
			}
			numb++;
		}
		if (days_chosen.size() == 0)
		{
			check = true;
			final_int = test_int;
		}
		for (int i = 0; i < days_chosen.size(); i++)
		{
			if (test_int == days_chosen.at(i))
				break;
			if (test_int != days_chosen.at(i) && i == days_chosen.size()-1)
			{
				check = true;
				final_int = test_int;
			}
		}
	}
	return final_int;
}

vector<int> choosedays(int nb_days,int timehorizon)
{
	vector<double> weights = createroulette(timehorizon);
	vector<int> days_chosen;
	vector<int> days_tobechoose;
	for (int i = 0; i < timehorizon; i++)
	{
		days_tobechoose.push_back(i);
	}
	for (int i = 0; i < nb_days; i++)
	{
		int drew = draw(weights, days_chosen, days_tobechoose);
		days_chosen.push_back(drew);
	}
	/*
	for (int i = 0; i < days_chosen.size(); i++)
	{
		cout << days_chosen.at(i) << endl;
	}
	*/
	return days_chosen;
}
int main()
{
	//We define the parameters and initialise vectors (setup)
	int Number_of_historics = 10; int Nb_Cust = 1000; int nb_Segments = 1;
	/*
	double beta_a = 1.25; double beta_e = 1.5; double beta_b = 0.75; 
	double beta_c = 0.75; double beta_d = 1.00; double beta_p = -2.;
	int timehorizon = 5;
	//unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	//std::default_random_engine generator(seed);
	vector<double> vbetas;
	vbetas.push_back(beta_a);
	vbetas.push_back(beta_b);
	vbetas.push_back(beta_c);
	vbetas.push_back(beta_d);
	vbetas.push_back(beta_e);
	vbetas.push_back(beta_p);

	const int nrolls = 10000;  // number of experiments
	const int nstars = 100;    // maximum number of stars to distribute
	const int nintervals = 20; // number of intervals
	const int first = -5;      // first interval

	std::default_random_engine generator;
	std::extreme_value_distribution<double> distribution(0.0, 1.0);

	int p[nintervals] = {};

	for (int i = 0; i < nrolls; ++i) {
		double number = distribution(generator);
		if ((number >= -5.0) && (number < 15.0)) ++p[int(number - first)];
	}

	std::cout << "extreme_value_distribution (2.0,4.0):" << std::endl;

	for (int i = 0; i < nintervals; ++i) {
		std::cout.width(2); std::cout << float(first + i) << "..";
		std::cout.width(2); std::cout << float(first + i + 1) << ": ";
		std::cout << std::string(p[i] * nstars / nrolls, '*') << std::endl;
	}
	*/

	//We iterate on the number of instances we want for the parameters defined
	for (int i = 1; i <= Number_of_historics; i++)
	{
		cout << i << endl;
		char Instance_Name[50];
		char Size_Name[50];
		sprintf(Instance_Name, "Data_%d%d.txt", i,Nb_Cust);
		sprintf(Size_Name, "Size_%d%d.txt", i, Nb_Cust);
		std::ofstream Instance(Instance_Name);
		std::ofstream Size(Size_Name);
		for (int j = 1; j <= Nb_Cust; j++)
		{
			int horizon_temp = 5;
			int days_toassign = 5;
			vector<Alternative> alternatives;
			vector<int> days_chosen = choosedays(days_toassign, horizon_temp);
			for (int k = 0; k < days_chosen.size(); k++)
			{
				Alternative alt;
				alt.assignday(days_toassign, days_chosen.at(k));
				alternatives.push_back(alt);
			}
			Alternative alt;
			alt.assignday(days_toassign, -1);
			alternatives.push_back(alt);
			for (int k = 0; k < alternatives.size(); k++)
			{
				string alt = to_string(alternatives.at(k).attributs.at(0).valeur);
				for (int l = 1; l < alternatives.at(k).attributs.size(); l++)
				{
					alt = alt + "," + to_string(alternatives.at(k).attributs.at(l).valeur);
				}
				alt = alt + "," + to_string(alternatives.at(k).price);
				Instance << alt << endl;
			}
			Size << days_toassign + 1 << "," << 1 << endl;
		}
	}
	cin.get();
}
