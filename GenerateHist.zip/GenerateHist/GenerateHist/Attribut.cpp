class Attribut
{
	public:
		Attribut(int val) { valeur = val; }
		int valeur;
};